﻿namespace Discord.Net.WebSockets
{
    public delegate IWebSocketClient WebSocketProvider();
}
