﻿namespace Discord
{
    public enum UserStatus
    {
        Offline,
        Online,
        Idle,
        AFK,
        DoNotDisturb,
        Invisible,
    }
}
