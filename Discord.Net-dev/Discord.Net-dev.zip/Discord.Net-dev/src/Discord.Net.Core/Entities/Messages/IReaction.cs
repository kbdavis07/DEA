﻿namespace Discord
{
    public interface IReaction
    {
        Emoji Emoji { get; }
    }
}
