﻿namespace Discord
{
    public interface ISystemMessage : IMessage
    {
    }
}
