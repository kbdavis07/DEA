﻿namespace Discord.Commands
{
    public enum RunMode
    {
        Default,
        Sync,
        Async
    }
}
