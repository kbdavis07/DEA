﻿#pragma warning disable CS1591
using System;

namespace Discord.API
{
    [AttributeUsage(AttributeTargets.Property)]
    internal class Int53Attribute : Attribute { }
}
