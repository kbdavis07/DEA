using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Discord.Net.Tests")]